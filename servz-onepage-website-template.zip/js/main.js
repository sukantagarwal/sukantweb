

;(function () {

	'use strict';

    //Scroll Effect
    AOS.init({
      easing: 'ease-in-out-sine'
    });


}());
