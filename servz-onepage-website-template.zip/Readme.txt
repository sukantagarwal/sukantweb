SERVZ - Onepage Website Template
By : LSR


Features:
-------------------------------------
- Fully Responsive
- HTML5 + CSS3
- Bootstrap Grid
- Sass Files Included
- Fully Customizable


Credits
-------------------------------------
- Bootstrap
- AOS		    -   https://github.com/michalsnik/aos
- jQuery
- jQuery Easing	    -   http://gsgd.co.uk/sandbox/jquery/easing/
- Modernizr-2
- Smooth Scroll     -   https://github.com/cferdinandi/smooth-scroll
- Pixabay           -   https://pixabay.com/
- Fontawesome       -   https://fontawesome.io/
- PHP Mailer        -   https://github.com/PHPMailer/PHPMailer/
- Google Fonts      -   https://fonts.google.com/


----------------------------------------

Design By:LSR
selthemes.wordpress.com
